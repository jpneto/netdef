ReadMe File - Neural Network Simulator

October 2nd, 2010.

Contact us at:
fsilva@di.fc.ul.pt
jpn@di.fc.ul.pt
http://homepages.di.fc.ul.pt/~jpn/

1) First Translation: Programs to Networks.
- The netdef folder contains the files referring to this translation.

	1.1) Programs developed using the NETDEF compiler:
		- bsort, it represents the parallel sorting of 10 arrays of 
		ten elements each using the bubble sort algorithm.
		
		- matrix3x3, the parallel computing of the product of two 3x3 matrices.
		
		- matrix4x4, the parallel computing of the product of two 4x4 matrices.
		
	1.2) Equations files
		The remaining files in the netdef folder represent the network description
		to the programs mentioned above, in the form of equations. The folder yet 
		includes another equations file, the isort_equations file, that's the
		translation of a program analogous to bsort.txt but instead the insertion
		sort algorithm was used.
		
		The programs to be translated can be specified in the settings file.
		If this doesn't occur, the simulator assumes that all 4 equation files 
		are supposed to be translated.
		
2) Second Translation: Networks to Tuples
	This is where the simulator's work starts.
	The simulator uses the equations file referring to a given program
	and translates it into tuples describing the network topology.
	This translation is essentially made in two steps:
	
	2.1) Calculating the precedences between the several groups of neurons;
		 The precedences files are placed in the preceds folder.
	
	2.2) Assembling the triples.
		 The triples for each network description are placed in the triples folder.
	
	The tags folder represent the several neurons involved in each description/translation.
	
3) Simulation

	3.1) SIMULATION SETTINGS
	The simulator allows the user to simulate the network execution through the triples,
	and using a user-defined number of parallel CPU's. This value is specified in the
	settings.txt file. This means that if you want to run the simulator using 40 CPUs,
	you just have to change the value in the settings file before the execution.
	If an invalid value is specified (like negative numbers), the simulator uses the
	default value of 25 parallel processing units.
	The same applies to load distribution strategies (discussed below), if no strategy is
	specified in the settings file, the simulator uses ONLY the naive distribution method.
	
	3.2) Distributing Triples
	Obviously, the triples have to be distributed among all existing the processing units.
	The user can specify which of the 5 existing distribution algorithms he wants to use,
	specifying them also in the settings.txt file.
	The algorithms are:
	- Round-Robin: Naive distribution of the triples among the CPUs, according with
	a Round-Robin mechanism.
	
	From now on, the triples are distributed according to their precedences and 
	dependencies in their execution, in order to maximize the parallel execution
	of tasks that are not related.
		
	- Uniform: Distribution of the sets among CPUs according to a Round-Robin mechanism.
	
	- Least-loaded: In the distribution, the next set is assign to the least loaded
	CPU, i.e., the CPU with the lowest total number of triples assigned (not sets!).
	
	- Precedences+randomization: Similar to Uniform, except that a random set 
	is assign to the next CPU.
	
	- Greedy: Similar to Uniform, except that the biggest set available is 
	assigned to the next CPU.
	
4) Simulation Results
	Since this is a simulator, there is the need the collect data from the simulations.
	The simulator collects:
	
	4.1) Triples per CPU: The number of triples assigned to the busiest processing unit
	and the number of CPUs involved in the simulation.
	
	4.2) Conflicting Writes: The maximum of potentially conflicting writes 
	in the simulation.
	
	4.3) Averages: Deviations, gets (readings in the shared memory segment) and
	triples average.
	
5) How to execute the simulator?

	- Extract the content of the zip archive into a folder.
	- Run the NeuralNetworkSimulator.jar. We recommend the use of a console
	(like Windows console or a terminal) due to the simulator's step by step
	output messages.
	- During simulation, the files in all folders (except netdef folder) are updated.
	
	NOTE: Do not change any file location.
	